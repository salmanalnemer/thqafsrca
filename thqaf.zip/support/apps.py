from django.apps import AppConfig


class SupportConfig(AppConfig):
    name = 'support'
    verbose_name = 'الدعم الفني'
