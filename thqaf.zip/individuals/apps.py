from django.apps import AppConfig


class IndividualsConfig(AppConfig):
    name = 'individuals'
    verbose_name = 'الأفراد'
