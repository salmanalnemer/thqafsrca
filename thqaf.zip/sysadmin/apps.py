from django.apps import AppConfig

class SysAdminConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sysadmin"
    verbose_name = "لوحة مدير النظام"
