from django.apps import AppConfig


class AttendanceConfig(AppConfig):
    name = 'attendance'
    verbose_name = 'حضور الدورات'