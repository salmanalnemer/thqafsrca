# trainers/views.py
from django.shortcuts import render  # موجود عندك بالفعل :contentReference[oaicite:1]{index=1}

def trainers_dashboard_view(request):
    # سيبحث Django عن القالب داخل templates/trainers_temp/dashboard.html
    return render(request, "trainers_temp/dashboard.html")
