from django.urls import path
from .views import trainers_dashboard_view

urlpatterns = [
    path("trainers/", trainers_dashboard_view, name="dashboard"),
]
