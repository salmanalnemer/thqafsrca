from django.apps import AppConfig


class CertificatesConfig(AppConfig):
    name = 'certificates'
    verbose_name = 'الشهادات'
