default_app_config = "trainers.apps.TrainersConfig"
