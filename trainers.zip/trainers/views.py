# trainers/views.py
from __future__ import annotations

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import redirect, render

from accounts.models import UserRole


@login_required
def trainers_dashboard_view(request):
    # ✅ منع أي مستخدم غير "مدرب" من دخول لوحة المدربين
    if getattr(request.user, "role", None) != UserRole.TRAINER:
        # لو تبي نفس سلوك باقي البوابات: نطلع المستخدم ونرجعه للدخول
        try:
            messages.error(request, "غير مصرح لك بالدخول إلى لوحة المدربين.")
        except Exception:
            pass
        return HttpResponseForbidden("غير مصرح لك بالدخول.")

    # سيبحث Django عن القالب داخل templates/trainers_temp/dashboard.html
    return render(request, "trainers_temp/dashboard.html")
