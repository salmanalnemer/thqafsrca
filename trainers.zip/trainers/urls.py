from django.urls import path
from . import views

app_name = "trainers"

urlpatterns = [
    path("dashboard/", views.trainers_dashboard_view, name="dashboard"),
]
